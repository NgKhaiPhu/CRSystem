#include <iostream>
#include <iomanip>
#include <fstream>
using namespace std;
struct Course{
    int no;
    string CoId;
    string CoName;
    string teacherName;
    int credit;
    int maxSt = 50;
    string day[2];
    string s[2];
    Course*next;
};
struct Sem{
    int year;
    string SemStart;
    string SemEnd;
    string regisStart;
    string regisEnd;
    Course s;
    Course*head=nullptr;
    Course*cur=nullptr;
};

void TCmenu(Sem se, Sem srr[], int i, int year);
void create_courselist(Sem &se, Sem srr[], int &i, int &year);
void displayCourseList(Sem se, Sem srr[], int i, int year);
void deleteCourse(Sem &se, Sem srr[]);
void read_data(Sem se, Sem srr[], int i, int year);

void TCmenu(Sem se, Sem srr[], int i, int year){
    int option;
    do{
        cout << endl;
        cout << "\t\t\t============================================" << endl;
        cout << "\t\t\t=          Press 0 to Endtask              =" << endl;
        cout << "\t\t\t=                1 to Create Courses       =" << endl;
        cout << "\t\t\t=                2 to Delete Courses       =" << endl;
        cout << "\t\t\t=                3 to Display List         =" << endl;
        cout << "\t\t\t============================================" << endl;
        cout << "\t\t\tOption => "; cin>> option;
        if (option==1){create_courselist(se, srr, i, year);}
        if (option==2){deleteCourse(se, srr);}
        if (option==3){displayCourseList(se, srr, i, year);}
    } while (option!=0);
}



void create_courselist(Sem &se, Sem srr[], int &i, int &year){
    cout << "\t\t\t============================================" << endl;
    cout << "\t\t\t=   Create a List of Course for this Sem   =" << endl;
    cout << "\t\t\t============================================" << endl;
    cout << "\t\t\tThe Year of Current Sem: "; 
    cin >> year;
    cout << "\t\t\t---------------------------" << endl;
    cout << "\t\t\tWhich Sem?" << endl;
    cout << "\t\t\t-> Press 1 for Fall" << endl;
    cout << "\t\t\t-> Press 2 for Summner" << endl;
    cout << "\t\t\t-> Press 3 for Autumn" << endl;
    cout << "\t\t\t---------------------------" << endl;
    cout << "\t\t\t=> ";
    cin >> i; i=i-1;
    cout << "\t\t\t---------------------------" << endl;
    cin.ignore(32727, '\n');
    cout << "\t\t\tWhen is this Sem start and end?" << endl;
    cout << "\t\t\tStart in: "; 
    getline(cin, srr[i].SemStart);
    cout << "\t\t\tEnd in: ";
    getline(cin, srr[i].SemEnd);
    cout << "\t\t\t---------------------------" << endl;
    cout << "\t\t\tWhen the registion start and end?" << endl;
    cout << "\t\t\tStart in: ";
    getline(cin, srr[i].regisStart);
    cout << "\t\t\tEnd in: ";
    getline(cin, srr[i].regisEnd);
    cout << "\t\t\t---------------------------" << endl;
    cout << "\t\t\t(Enter 0 in No to stop inserting!)" << endl;
    int No;
    cout << "\t\t\tNo: "; 
    cin>>No;
    srr[i].cur=nullptr;
    while (No!=0){
        if (srr[i].head==nullptr){
            srr[i].head= new Course;
            srr[i].cur=srr[i].head;
        } else {
            srr[i].cur->next=new Course;
            srr[i].cur=srr[i].cur->next;
        } cin.ignore(32767, '\n');
        cout << "\t\t\tId of Course: ";
        srr[i].cur->no=No;
        getline(cin, srr[i].cur->CoId);
        cout << "\t\t\tName of course: ";
        getline(cin, srr[i].cur->CoName);
        cout << "\t\t\tTeacher in class: ";
        getline(cin, srr[i].cur->teacherName);
        cout << "\t\t\tNumber of credits: "; 
        cin >> srr[i].cur->credit;
        cin.ignore(32767, '\n');
        for (int j=0; j<2; j++){
            cout << "\t\t\tDay " <<j+1<< ": ";
            getline(cin, srr[i].cur->day[j]);
        }
        for (int j=0; j<2; j++){
            cout << "\t\t\tS" << j+1 << ": ";
            getline(cin, srr[i].cur->s[j]);
        }
        srr[i].cur->next=nullptr;
        cout << "\t\t\tNo: "; 
        cin>>No;
    }
}


void displayCourseList(Sem se, Sem srr[], int i, int year){
    srr[i].cur=srr[i].head;
    cout << endl << endl;
    cout << setfill(' ');
    cout << "Course List of Sem " << i+1 << " in the year of " << year << " ,which from ";
    cout << srr[i].SemStart << " to " << srr[i].SemEnd << endl;
    cout << "===================================================================================================" << endl;
    cout << "Registion time is from " << srr[i].regisStart << " to " << srr[i].regisEnd << endl;
    cout << "===================================================================================================" << endl;
    cout << setw(13) << left << "ID";
    cout << setw(15) << left <<  "Course";
    cout << setw(17) << left <<  "Teacher";
    cout << setw(10) << left <<  "Credit";
    cout << setw(10) << left <<  "Maximum";
    cout << setw(12) << left <<  "Day";
    cout << "Seassion"; 
    cout << endl;
    while (srr[i].cur!=nullptr){
        cout << setfill(' ');
        cout << setw(13) << left <<  srr[i].cur->CoId;
        cout << setw(15) << left <<  srr[i].cur->CoName;
        cout << setw(17) << left <<  srr[i].cur->teacherName;
        cout << setw(10) << left <<  srr[i].cur->credit;
        cout << setw(10) << left <<  srr[i].cur->maxSt;
        for (int j=0; j<2; j++){
            cout << setw(4) << left << srr[i].cur->day[j] << " ";
        } cout << "  ";
        for (int j=0; j<2; j++){
            cout << "S" << j+1 << ": ";
            cout << setw(7) << srr[i].cur->s[j] << "  ";
        }
        cout << endl;
        srr[i].cur=srr[i].cur->next;
    }
}

void deleteCourse(Sem &se, Sem srr[]){
    string ids;
    int m;
    cout << endl;
    cout << "\t\t\tSem: ";
    cin>>m;
    cin.ignore(32767, '\n');
    cout << "\t\t\tCourse ID that need to delete: "; 
    getline(cin, ids);
    if (!srr[m].head){
        cout << "List not available!" << endl;
        return;
    }
    srr[m].cur=srr[m].head;
    if (srr[m].head->CoId==ids){
        srr[m].head=srr[m].head->next;
        delete srr[m].cur;
        srr[m].cur=nullptr;
    } else {
        while (srr[m].cur->next->CoId!=ids){
            srr[m].cur=srr[m].cur->next;
        } Course*link=srr[m].cur->next;
        srr[m].cur->next=srr[m].cur->next->next;
        delete link;
    }
}

void read_data(Sem se, Sem srr[], int i, int year){
    srr[i].cur=srr[i].head;
    ofstream ofs;
    ofs.open("CourseList.txt", ios::out);
    int ifake=i+1;
    ofs << ifake << endl;
    ofs << srr[i].SemStart << endl;
    ofs << srr[i].SemEnd << endl;
    ofs << srr[i].regisStart << endl;
    ofs << srr[i].regisEnd << endl;
    while (srr[i].cur!=nullptr){
        ofs << srr[i].cur->no << endl;
        ofs << srr[i].cur->CoId << endl;
        ofs << srr[i].cur->CoName << endl;
        ofs << srr[i].cur->teacherName << endl;
        ofs << srr[i].cur->credit << endl;
        ofs << srr[i].cur->maxSt << endl;
        for (int j=0; j<2; j++){
            ofs << srr[i].cur->day[j] << endl;
        }
        for (int j=0; j<2; j++){
            ofs << srr[i].cur->s[j] << endl;
        }
        srr[i].cur=srr[i].cur->next;
    } ofs << "0";
    ofs.close();
}

/*struct Course{
    int CoId;
    string CoName;
    string teacherName;
    int credit;
    int maxSt = 50;
    string day[2];
    string s[2];
    Course*next;
};
struct Sem{
    int year;
    string SemStart;
    string SemEnd;
    string regisStart;
    string regisEnd;
    Course s;
    Course*head=nullptr;
    Course*cur=nullptr;
};*/


int main(){
    int i, year;
    Sem se;
    Sem srr[3];
    TCmenu(se, srr, i, year);
    read_data(se, srr, i, year);
    return 0;
}